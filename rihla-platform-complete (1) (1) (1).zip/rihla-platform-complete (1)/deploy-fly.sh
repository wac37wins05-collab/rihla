#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  deploy-fly.sh — STOURS / Rihla  ·  Fly.io deployment script
#  Usage: bash deploy-fly.sh
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail

# ── Token (set your Fly.io token here or export FLY_API_TOKEN before running)
export FLY_API_TOKEN="${FLY_API_TOKEN:-FlyV1 fm2_lJPECAAAAAAAE6XKxBBiyHUmXoiYcPsp7OB9aGITwrVodHRwczovL2FwaS5mbHkuaW8vdjGUAJLOABigtR8Lk7lodHRwczovL2FwaS5mbHkuaW8vYWFhL3YxxDz1as8jMyIfUIVVh+k+zjE3mLXZRUr4+ZI2r4dh9AKQVczKNXbaPscztWFkDTVnTc3LkXAGDAwNFOkK8NPETlOMFWzp+zIc8hAksI/hPk1gCt5zenPsMzhw7RtZOelEPLc6Wpdv3gXsluF4XQfyPUqpKl4roiTU5VT0r+o7Dn5VGkYY71EnBTuMz0V7WsQgbszCAgnFZP9JOKJipR1HK9YG1pte7vm3jYRiLfNEZdg=,fm2_lJPETlOMFWzp+zIc8hAksI/hPk1gCt5zenPsMzhw7RtZOelEPLc6Wpdv3gXsluF4XQfyPUqpKl4roiTU5VT0r+o7Dn5VGkYY71EnBTuMz0V7WsQQ+IrlJpRmxLNDP83pWBR+EsO5aHR0cHM6Ly9hcGkuZmx5LmlvL2FhYS92MZgEks5p/1FIzwAAAAEl929mF84AF5m3CpHOABeZtwzEEFNVMaUrzMAXgH6j+gLx/8jEICRCEUL5ihhMVot3KFH5Bej3uNlWRQnwTwJZmjB3f1zC}"

BACKEND_APP="stours-api"
FRONTEND_APP="stours-app"
REGION="cdg"

# ── Colours ──────────────────────────────────────────────────────
GREEN='\033[0;32m'; BLUE='\033[0;34m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ── Check flyctl ──────────────────────────────────────────────────
if ! command -v fly &>/dev/null; then
  error "flyctl is not installed. Install it: curl -L https://fly.io/install.sh | sh"
fi
info "flyctl $(fly version --json 2>/dev/null | grep -o '"[0-9.]*"' | head -1 || fly version)"

# ── Verify token ──────────────────────────────────────────────────
info "Authenticating with Fly.io token..."
fly auth whoami || error "Token invalid — check FLY_API_TOKEN"
success "Authenticated"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ════════════════════════════════════════════════════════════════════
# 1. BACKEND (FastAPI)
# ════════════════════════════════════════════════════════════════════
info "━━━ Deploying BACKEND ($BACKEND_APP) ━━━"
cd "$SCRIPT_DIR/backend"

# Create app if it doesn't exist
if ! fly apps list 2>/dev/null | grep -q "$BACKEND_APP"; then
  info "Creating app $BACKEND_APP..."
  fly apps create "$BACKEND_APP" --org personal
  success "App created"
else
  info "App $BACKEND_APP already exists"
fi

# Provision Postgres if not already linked
if ! fly postgres list 2>/dev/null | grep -q "stours-db"; then
  info "Creating Fly Postgres cluster (stours-db)..."
  fly postgres create \
    --name stours-db \
    --region "$REGION" \
    --initial-cluster-size 1 \
    --vm-size shared-cpu-1x \
    --volume-size 3
  info "Attaching Postgres to $BACKEND_APP..."
  fly postgres attach stours-db --app "$BACKEND_APP"
  success "Postgres attached — DATABASE_URL secret set automatically"
else
  warn "Postgres cluster 'stours-db' already exists — skipping creation"
fi

# Set required secrets (edit these values before running)
info "Setting backend secrets..."
fly secrets set \
  --app "$BACKEND_APP" \
  JWT_SECRET="$(openssl rand -hex 32)" \
  ENVIRONMENT="production" \
  FRONTEND_URL="https://${FRONTEND_APP}.fly.dev" \
  WORKERS="2"

# Optional secrets — uncomment and fill in if needed:
# fly secrets set --app "$BACKEND_APP" \
#   ANTHROPIC_API_KEY="sk-ant-..." \
#   SMTP_HOST="smtp.mailgun.org" \
#   SMTP_PORT="587" \
#   SMTP_USER="postmaster@yourdomain.ma" \
#   SMTP_PASS="your_smtp_password" \
#   AWS_ACCESS_KEY_ID="your_key" \
#   AWS_SECRET_ACCESS_KEY="your_secret" \
#   AWS_REGION="eu-west-3" \
#   S3_BUCKET="stours-files"

# Deploy backend
info "Building & deploying backend Docker image..."
fly deploy --app "$BACKEND_APP" --region "$REGION" --wait-timeout 300
success "Backend deployed → https://${BACKEND_APP}.fly.dev"

# ════════════════════════════════════════════════════════════════════
# 2. FRONTEND (React + Nginx)
# ════════════════════════════════════════════════════════════════════
info "━━━ Deploying FRONTEND ($FRONTEND_APP) ━━━"
cd "$SCRIPT_DIR/frontend"

# Create app if it doesn't exist
if ! fly apps list 2>/dev/null | grep -q "$FRONTEND_APP"; then
  info "Creating app $FRONTEND_APP..."
  fly apps create "$FRONTEND_APP" --org personal
  success "App created"
else
  info "App $FRONTEND_APP already exists"
fi

# Set BACKEND_URL so nginx entrypoint can proxy correctly
fly secrets set \
  --app "$FRONTEND_APP" \
  BACKEND_URL="https://${BACKEND_APP}.fly.dev"

# Deploy frontend
info "Building & deploying frontend Docker image..."
fly deploy \
  --app "$FRONTEND_APP" \
  --region "$REGION" \
  --build-arg VITE_API_URL="https://${BACKEND_APP}.fly.dev" \
  --wait-timeout 300
success "Frontend deployed → https://${FRONTEND_APP}.fly.dev"

# ════════════════════════════════════════════════════════════════════
# Summary
# ════════════════════════════════════════════════════════════════════
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   STOURS / Rihla — déploiement Fly.io terminé   ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  🌐 Frontend  →  ${BLUE}https://${FRONTEND_APP}.fly.dev${NC}"
echo -e "  ⚙️  API       →  ${BLUE}https://${BACKEND_APP}.fly.dev/docs${NC}"
echo ""
echo -e "  Utile:"
echo -e "    fly logs --app $BACKEND_APP      # logs backend en temps réel"
echo -e "    fly logs --app $FRONTEND_APP     # logs frontend"
echo -e "    fly status --app $BACKEND_APP    # santé des machines"
echo -e "    fly ssh console --app $BACKEND_APP  # shell dans le conteneur"
echo ""
