@echo off
REM ═══════════════════════════════════════════════════════
REM  deploy-fly.bat  —  STOURS Fly.io  (Windows CMD)
REM  Run from the project root directory.
REM ═══════════════════════════════════════════════════════

SET FLY_API_TOKEN=FlyV1 fm2_lJPECAAAAAAAE6XKxBBiyHUmXoiYcPsp7OB9aGITwrVodHRwczovL2FwaS5mbHkuaW8vdjGUAJLOABigtR8Lk7lodHRwczovL2FwaS5mbHkuaW8vYWFhL3YxxDz1as8jMyIfUIVVh+k+zjE3mLXZRUr4+ZI2r4dh9AKQVczKNXbaPscztWFkDTVnTc3LkXAGDAwNFOkK8NPETlOMFWzp+zIc8hAksI/hPk1gCt5zenPsMzhw7RtZOelEPLc6Wpdv3gXsluF4XQfyPUqpKl4roiTU5VT0r+o7Dn5VGkYY71EnBTuMz0V7WsQgbszCAgnFZP9JOKJipR1HK9YG1pte7vm3jYRiLfNEZdg=,fm2_lJPETlOMFWzp+zIc8hAksI/hPk1gCt5zenPsMzhw7RtZOelEPLc6Wpdv3gXsluF4XQfyPUqpKl4roiTU5VT0r+o7Dn5VGkYY71EnBTuMz0V7WsQQ+IrlJpRmxLNDP83pWBR+EsO5aHR0cHM6Ly9hcGkuZmx5LmlvL2FhYS92MZgEks5p/1FIzwAAAAEl929mF84AF5m3CpHOABeZtwzEEFNVMaUrzMAXgH6j+gLx/8jEICRCEUL5ihhMVot3KFH5Bej3uNlWRQnwTwJZmjB3f1zC

echo [1/6] Verifying flyctl...
fly auth whoami
IF %ERRORLEVEL% NEQ 0 (
  echo ERROR: Token invalid. Download flyctl: https://fly.io/install.sh
  exit /b 1
)

echo [2/6] Creating backend app (stours-api)...
fly apps create stours-api --org personal 2>NUL || echo App already exists

echo [3/6] Deploying backend...
cd backend
fly deploy --app stours-api --region cdg --wait-timeout 300
cd ..

echo [4/6] Creating frontend app (stours-app)...
fly apps create stours-app --org personal 2>NUL || echo App already exists

echo [5/6] Setting frontend backend URL...
fly secrets set --app stours-app BACKEND_URL=https://stours-api.fly.dev

echo [6/6] Deploying frontend...
cd frontend
fly deploy --app stours-app --region cdg --build-arg VITE_API_URL=https://stours-api.fly.dev --wait-timeout 300
cd ..

echo.
echo ============================================================
echo  STOURS deploye sur Fly.io !
echo  Frontend : https://stours-app.fly.dev
echo  API      : https://stours-api.fly.dev/docs
echo ============================================================
