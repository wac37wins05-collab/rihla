/**
 * Auth setup — logs in once, saves auth state to a file.
 * All other tests reuse this state (faster, no repeated login).
 */
import { test as setup, expect } from '@playwright/test'
import * as fs from 'fs'
import * as path from 'path'

const AUTH_FILE = path.join(__dirname, '.auth/user.json')

setup('authenticate as super_admin', async ({ page }) => {
  await page.goto('/login')

  // Fill credentials (seeded by seed_admin.py / seed_users.py)
  await page.getByLabel(/email/i).fill('a.chakir@stours.ma')
  await page.getByLabel(/mot de passe|password/i).fill('Abdo@1937')
  await page.getByRole('button', { name: /connexion|se connecter|login/i }).click()

  // Wait for post-login redirect to dashboard
  await page.waitForURL(/\/(dashboard|projects|portal)/, { timeout: 15_000 })
  await expect(page).not.toHaveURL(/\/login/)

  // Persist auth state (cookies + localStorage token)
  await page.context().storageState({ path: AUTH_FILE })
})
