# deploy-fly.ps1 — Deploy RIHLA to Fly.io (3 services)
# Run from PowerShell: .\deploy-fly.ps1

$ErrorActionPreference = "Stop"

$FLY_TOKEN = "fm2_lJPECAAAAAAAE6XKxBBiyHUmXoiYcPsp7OB9aGITwrVodHRwczovL2FwaS5mbHkuaW8vdjGUAJLOABigtR8Lk7lodHRwczovL2FwaS5mbHkuaW8vYWFhL3YxxDz1as8jMyIfUIVVh+k+zjE3mLXZRUr4+ZI2r4dh9AKQVczKNXbaPscztWFkDTVnTc3LkXAGDAwNFOkK8NPETlOMFWzp+zIc8hAksI/hPk1gCt5zenPsMzhw7RtZOelEPLc6Wpdv3gXsluF4XQfyPUqpKl4roiTU5VT0r+o7Dn5VGkYY71EnBTuMz0V7WsQgbszCAgnFZP9JOKJipR1HK9YG1pte7vm3jYRiLfNEZdg="

$env:FLY_API_TOKEN = $FLY_TOKEN

$ROOT = $PSScriptRoot

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  RIHLA Platform — Fly.io Deployment" -ForegroundColor Cyan
Write-Host "========================================`n" -ForegroundColor Cyan

# Check flyctl installed
if (-not (Get-Command flyctl -ErrorAction SilentlyContinue)) {
    Write-Host "Installing flyctl..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri https://fly.io/install.ps1 -OutFile "$env:TEMP\fly-install.ps1"
    & "$env:TEMP\fly-install.ps1"
    $env:PATH += ";$env:USERPROFILE\.fly\bin"
}

# ── 1. Deploy Billing Engine ──────────────────────────────────────
Write-Host "[1/3] Deploying billing engine (stours-billing)..." -ForegroundColor Green
Set-Location "$ROOT\billing-engine"

# Create app if it doesn't exist
flyctl apps create stours-billing --machines 2>$null

# Set DATABASE_URL secret (update this with your actual Postgres URL)
# flyctl secrets set DATABASE_URL="postgresql://..." --app stours-billing

flyctl deploy --remote-only --app stours-billing
if ($LASTEXITCODE -ne 0) {
    Write-Host "Billing engine deploy failed. Check DATABASE_URL secret." -ForegroundColor Red
    Write-Host "Run: flyctl secrets set DATABASE_URL='postgresql://...' --app stours-billing" -ForegroundColor Yellow
}

# ── 2. Deploy Backend API ─────────────────────────────────────────
Write-Host "`n[2/3] Deploying backend API (stours-api)..." -ForegroundColor Green
Set-Location "$ROOT\backend"
flyctl deploy --remote-only --app stours-api
if ($LASTEXITCODE -ne 0) {
    Write-Host "Backend deploy failed." -ForegroundColor Red
}

# ── 3. Deploy Frontend ────────────────────────────────────────────
Write-Host "`n[3/3] Deploying frontend (stours-app)..." -ForegroundColor Green
Set-Location "$ROOT\frontend"
flyctl deploy --remote-only --app stours-app
if ($LASTEXITCODE -ne 0) {
    Write-Host "Frontend deploy failed." -ForegroundColor Red
}

# ── Done ────────────────────────────────────────────────────────��─
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  Deployment complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Frontend  : https://stours-app.fly.dev" -ForegroundColor White
Write-Host "  Backend   : https://stours-api.fly.dev" -ForegroundColor White
Write-Host "  Billing   : https://stours-billing.fly.dev" -ForegroundColor White
Write-Host "  API Docs  : https://stours-billing.fly.dev/api/docs" -ForegroundColor White
Write-Host ""
Write-Host "  NOTE: Set DATABASE_URL secrets for billing engine:" -ForegroundColor Yellow
Write-Host "  flyctl secrets set DATABASE_URL='postgresql://...' --app stours-billing" -ForegroundColor Yellow

Set-Location $ROOT
